# Football draw simulator
A small app simulating UEFA Champions League group stage draw.
Draw 32 teams into 8 groups and see their upcoming fixtures.

![Alt text](./app/img/img.png?raw=true "Champions League Draw Simulator")
